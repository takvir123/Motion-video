import {loadFont} from "@remotion/google-fonts/HindSiliguri";

// Loaded through Remotion's font loader: rendering waits until the font is ready.
const {fontFamily} = loadFont("normal", {
  weights: ["500", "600", "700"],
  subsets: ["bengali", "latin"],
});

export const FONT = `${fontFamily}, 'Noto Sans Bengali', sans-serif`;
export const WIDTH = 1920;
export const HEIGHT = 1080;

export const C = {
  bg: "#FAF9F6",
  white: "#FFFFFF",
  orange: "#F97316",
  orangeDark: "#EA580C",
  orangeSoft: "#FFEDD5",
  amber: "#FDBA74",
  black: "#18181B",
  charcoal: "#27272A",
  gray: "#71717A",
  border: "#E7E5E4",
};

export const SHADOW =
  "0 28px 60px -24px rgba(24,24,27,0.18), 0 2px 8px rgba(24,24,27,0.05)";
