import React from "react";
import {Composition} from "remotion";
import {TohaPromo} from "./Composition";
import {FPS, TOTAL_FRAMES} from "./utils/timing";
import {HEIGHT, WIDTH} from "./styles/theme";

export const RemotionRoot: React.FC = () => (
  <Composition
    id="TohaPromo"
    component={TohaPromo}
    durationInFrames={TOTAL_FRAMES}
    fps={FPS}
    width={WIDTH}
    height={HEIGHT}
  />
);
