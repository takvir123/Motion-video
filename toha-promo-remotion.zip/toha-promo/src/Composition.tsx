import React from "react";
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame} from "remotion";
import {Background} from "./components/Background";
import {C, FONT} from "./styles/theme";
import {SCENES, SceneId, TOTAL_FRAMES} from "./utils/timing";
import {Scene01} from "./scenes/Scene01";
import {Scene02} from "./scenes/Scene02";
import {Scene03} from "./scenes/Scene03";
import {Scene04} from "./scenes/Scene04";
import {Scene05} from "./scenes/Scene05";
import {Scene06} from "./scenes/Scene06";
import {Scene07} from "./scenes/Scene07";
import {Scene08} from "./scenes/Scene08";
import {Scene09} from "./scenes/Scene09";
import {Scene10} from "./scenes/Scene10";

const SCENE_COMPONENTS: Record<SceneId, React.FC> = {
  s1: Scene01, s2: Scene02, s3: Scene03, s4: Scene04, s5: Scene05,
  s6: Scene06, s7: Scene07, s8: Scene08, s9: Scene09, s10: Scene10,
};

const ProgressBar: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <div style={{position: "absolute", left: 0, bottom: 0, height: 6, width: `${(f / TOTAL_FRAMES) * 100}%`, background: C.orange, opacity: 0.85}} />
  );
};

export const TohaPromo: React.FC = () => (
  <AbsoluteFill style={{fontFamily: FONT, overflow: "hidden"}}>
    <Background />
    {/* Original voice-over, unmodified. Put the file at public/audio/voiceover.ogg */}
    <Audio src={staticFile("audio/voiceover.ogg")} />
    {(Object.keys(SCENES) as SceneId[]).map((id) => {
      const Scene = SCENE_COMPONENTS[id];
      return (
        <Sequence key={id} from={SCENES[id].start} durationInFrames={SCENES[id].end - SCENES[id].start} name={id}>
          <Scene />
        </Sequence>
      );
    })}
    <ProgressBar />
  </AbsoluteFill>
);
