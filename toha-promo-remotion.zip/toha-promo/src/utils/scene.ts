import {useCurrentFrame} from "remotion";
import {SCENES, SceneId, cueFrame} from "./timing";

/** Local frame + helper converting a JSON word index to a scene-local frame. */
export const useScene = (id: SceneId) => {
  const f = useCurrentFrame();
  const s = SCENES[id];
  return {
    f,
    start: s.start,
    dur: s.end - s.start,
    at: (wordIndex: number) => cueFrame(wordIndex) - s.start,
  };
};
