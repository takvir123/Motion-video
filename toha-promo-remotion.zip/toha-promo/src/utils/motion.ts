import {Easing, interpolate, spring} from "remotion";
import {FPS} from "./timing";

type EasingFn = (t: number) => number;

export const ease = (
  f: number, start: number, dur = 20,
  easing: EasingFn = Easing.out(Easing.cubic),
) =>
  interpolate(f, [start, start + Math.max(1, dur)], [0, 1], {
    extrapolateLeft: "clamp", extrapolateRight: "clamp", easing,
  });

export const easeIO = (f: number, start: number, dur = 20) =>
  ease(f, start, dur, Easing.inOut(Easing.cubic));

export const pop = (f: number, start: number, config: Record<string, number> = {}) =>
  spring({
    frame: Math.max(0, f - start), fps: FPS,
    config: {damping: 15, stiffness: 110, mass: 0.9, ...config},
  });

export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const bob = (f: number, amp = 6, period = 100, phase = 0) =>
  Math.sin((f / period) * Math.PI * 2 + phase) * amp;

/** Latin digits -> Bengali digits. */
export const bn = (n: number | string) =>
  String(n).replace(/\d/g, (d) => "০১২৩৪৫৬৭৮৯"[Number(d)]);
