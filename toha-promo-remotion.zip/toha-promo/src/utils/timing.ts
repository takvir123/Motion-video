import raw from "../data/timestamps.json";

export const FPS = 30;

export type WordTiming = {word: string; start: string; end: string};
const words = raw.word_timestamps as WordTiming[];

/** "MM:SS.mmm" -> frame. Integer milliseconds avoid float drift (5.35*30 etc). */
export const timestampToFrame = (ts: string, fps: number = FPS): number => {
  const [mm, ss] = ts.split(":");
  const ms = Math.round((parseInt(mm, 10) * 60 + parseFloat(ss)) * 1000);
  return Math.round((ms * fps) / 1000);
};

export const getWordTiming = (wordIndex: number) => {
  const w = words[wordIndex];
  if (!w) throw new Error(`No word at index ${wordIndex}`);
  return {
    index: wordIndex,
    word: w.word,
    startFrame: timestampToFrame(w.start),
    endFrame: timestampToFrame(w.end),
  };
};

/** Absolute start frame of a word from the JSON. */
export const cueFrame = (wordIndex: number) => getWordTiming(wordIndex).startFrame;

/** Word indices in timestamps.json (0-based). Every animation cue is derived from these. */
export const W = {
  TOHA: 13, COMPUTER: 14, AND: 15, TRAINING: 16, CENTER: 17,
  THREE: 20, MICROSOFT: 23,
  PRICE1: 28,
  NINETY: 35, DIN: 36, SHOMPURNO: 37, COURSE2: 38,
  PROYOJONIYO: 40, PROSHIKKHON: 41, BOI: 42,
  GOVT: 46, APPROVED: 47, ONLINE: 48, VERIFIED: 49, CERT: 50,
  EASY: 51, ADMISSION: 56, PAY3000: 61, TWOMONTH: 64, PAY2500: 67,
  SPECIAL_OPP: 74, ADM2: 76, FIVE00: 84, SPECIAL: 86,
  OLDPRICE: 89, TRANSFORM: 92, MATRO2: 93, NEWPRICE: 94,
  AR: 96, DERI: 97, KENO: 98, AJI: 99, APNAR2: 100, ASON: 101, NISCHITO: 102,
  CONTACT: 104, BRAND1: 106, BRAND2: 107, BRAND3: 108, BRAND4: 109, BRAND5: 110,
};

export type SceneId = "s1" | "s2" | "s3" | "s4" | "s5" | "s6" | "s7" | "s8" | "s9" | "s10";
const T = timestampToFrame;
export const SCENES: Record<SceneId, {start: number; end: number}> = {
  s1: {start: T("00:00.000"), end: T("00:05.000")},
  s2: {start: T("00:05.000"), end: T("00:11.000")},
  s3: {start: T("00:11.000"), end: T("00:14.000")},
  s4: {start: T("00:14.000"), end: T("00:17.000")},
  s5: {start: T("00:17.000"), end: T("00:20.000")},
  s6: {start: T("00:20.000"), end: T("00:25.000")},
  s7: {start: T("00:25.000"), end: T("00:33.500")},
  s8: {start: T("00:33.500"), end: T("00:41.500")},
  s9: {start: T("00:41.500"), end: T("00:45.500")},
  s10: {start: T("00:45.500"), end: T("00:52.200")},
};
export const TOTAL_FRAMES = SCENES.s10.end; // 1566
