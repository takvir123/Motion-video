import React from "react";
import {C} from "../styles/theme";
import {AnimatedText, WordSpec} from "../components/AnimatedText";
import {CalendarAnimation, ProgressRing} from "../components/CalendarAnimation";
import {CameraRig} from "../components/CameraRig";
import {SceneTransition} from "../components/SceneTransition";
import {StepTag} from "../components/StepTag";
import {useScene} from "../utils/scene";
import {W} from "../utils/timing";

export const Scene04: React.FC = () => {
  const {dur, at} = useScene("s4");
  const n = at(W.NINETY);
  const lines: WordSpec[][] = [
    [{t: "৯০", at: n, color: C.orange, pulse: true}, {t: "দিনের", at: at(W.DIN)}],
    [{t: "সম্পূর্ণ", at: at(W.SHOMPURNO)}, {t: "কোর্স", at: at(W.COURSE2)}],
  ];
  return (
    <SceneTransition duration={dur} inFrames={10} outFrames={8} mode="fade">
      <CameraRig from={{scale: 1}} to={{scale: 1.02}} frames={dur}>
        <StepTag n={1} start={0} />
        <div style={{position: "absolute", left: 150, top: 340}}>
          <AnimatedText lines={lines} size={130} lineHeight={1.35} />
        </div>
        <CalendarAnimation x={1000} y={200} start={4} fillStart={n} fillEnd={n + 56} />
        <ProgressRing x={1400} y={540} size={300} start={14} fillStart={n} fillEnd={n + 56} />
      </CameraRig>
    </SceneTransition>
  );
};
