import React from "react";
import {C} from "../styles/theme";
import {AnimatedText, WordSpec} from "../components/AnimatedText";
import {CameraRig, Parallax} from "../components/CameraRig";
import {PaymentTimeline} from "../components/PaymentTimeline";
import {SceneTransition} from "../components/SceneTransition";
import {useScene} from "../utils/scene";
import {W} from "../utils/timing";

export const Scene07: React.FC = () => {
  const {dur, at} = useScene("s7");
  const title: WordSpec[][] = [[
    {t: "সহজ", at: at(W.EASY), color: C.orange}, {t: "পেমেন্ট", at: at(W.EASY) + 8}, {t: "সুবিধা", at: at(W.EASY) + 16},
  ]];
  return (
    <SceneTransition duration={dur} inFrames={10} outFrames={6} mode="fade">
      <CameraRig from={{x: 130}} to={{x: -130}} frames={dur}>
        <Parallax depth={-1}>
          <div style={{position: "absolute", left: 0, top: 80, width: 1920}}>
            <AnimatedText lines={title} size={96} align="center" />
          </div>
        </Parallax>
        <PaymentTimeline card1={at(W.ADMISSION)} hi1={at(W.PAY3000)} node2={at(W.TWOMONTH)}
          card2={at(W.TWOMONTH) - 12} hi2={at(W.PAY2500)} total={at(W.PAY2500) + 12} />
      </CameraRig>
    </SceneTransition>
  );
};
