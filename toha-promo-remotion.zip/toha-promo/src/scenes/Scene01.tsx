import React from "react";
import {Easing, interpolate} from "remotion";
import {C} from "../styles/theme";
import {CameraRig} from "../components/CameraRig";
import {FloatingCard} from "../components/FloatingCard";
import {Icon, IconName} from "../components/Icons";
import {LaptopIllustration} from "../components/LaptopIllustration";
import {SceneTransition} from "../components/SceneTransition";
import {bob, ease, lerp, pop} from "../utils/motion";
import {useScene} from "../utils/scene";

const ARROW = "M240 880 C500 880 600 760 800 780 C1000 800 1100 560 1300 520 C1480 485 1560 330 1660 210";
const SKILLS: {icon: IconName; tx: number; ty: number; at: number}[] = [
  {icon: "doc", tx: 1130, ty: 330, at: 55},
  {icon: "grid", tx: 1320, ty: 280, at: 68},
  {icon: "chart", tx: 1510, ty: 340, at: 81},
];

export const Scene01: React.FC = () => {
  const {f, dur} = useScene("s1");
  const arrowP = ease(f, 95, 40, Easing.inOut(Easing.cubic));
  const head = interpolate(arrowP, [0.92, 1], [0, 1], {extrapolateLeft: "clamp", extrapolateRight: "clamp"});
  const lapIn = ease(f, 0, 20);
  return (
    <SceneTransition duration={dur} inFrames={18} outFrames={14} mode="zoom">
      <CameraRig from={{scale: 1}} to={{scale: 1.06}} frames={dur}>
        <svg width="1920" height="1080" viewBox="0 0 1920 1080" style={{position: "absolute", left: 0, top: 0}}>
          <path d={ARROW} pathLength={1} fill="none" stroke={C.amber} strokeWidth="36" strokeLinecap="round"
            strokeDasharray="1" strokeDashoffset={1 - arrowP} opacity="0.5" />
          <path d={ARROW} pathLength={1} fill="none" stroke={C.orange} strokeWidth="14" strokeLinecap="round"
            strokeDasharray="1" strokeDashoffset={1 - arrowP} />
          <g transform="translate(1660 210) rotate(-50)" opacity={head}>
            <polygon points="10,0 -52,-32 -52,32" fill={C.orange} />
          </g>
        </svg>
        <div style={{position: "absolute", left: 580, top: 440 + (1 - lapIn) * 40, opacity: lapIn}}>
          <LaptopIllustration width={760} start={20} />
        </div>
        <FloatingCard x={250} y={190} w={480} h={190} start={20} from="left" radius={36} bobAmp={7}>
          <div style={{display: "flex", alignItems: "center", gap: 26, padding: "0 34px", height: "100%"}}>
            <svg width="92" height="92" viewBox="0 0 92 92">
              <circle cx="46" cy="46" r="46" fill={C.orangeSoft} />
              <circle cx="46" cy="36" r="15" fill={C.orange} />
              <path d="M16 80c4-18 16-26 30-26s26 8 30 26" fill={C.amber} />
            </svg>
            <div style={{display: "flex", flexDirection: "column", gap: 14}}>
              <div style={{background: C.orange, color: "#fff", fontSize: 36, fontWeight: 700, padding: "4px 22px", borderRadius: 99}}>ক্যারিয়ার</div>
              <div style={{width: 190, height: 12, borderRadius: 6, background: C.border}} />
              <div style={{width: 130, height: 12, borderRadius: 6, background: C.border}} />
            </div>
          </div>
        </FloatingCard>
        {SKILLS.map((s, i) => {
          const p = pop(f, s.at, {damping: 13, stiffness: 120});
          const o = ease(f, s.at, 8);
          return (
            <div key={s.icon} style={{
              position: "absolute", left: lerp(960, s.tx, p) - 65, top: lerp(640, s.ty, p) - 65 + bob(f, 7, 100, i) * o,
              width: 130, height: 130, borderRadius: "50%", background: C.white, border: `2px solid ${C.border}`,
              display: "flex", alignItems: "center", justifyContent: "center", opacity: o, transform: `scale(${0.5 + 0.5 * Math.min(1, p)})`,
              boxShadow: "0 22px 44px -20px rgba(24,24,27,0.25)",
            }}><Icon name={s.icon} size={66} /></div>
          );
        })}
        <div style={{
          position: "absolute", left: 1200, top: 150, background: C.orange, color: "#fff", fontSize: 38, fontWeight: 700,
          letterSpacing: 5, padding: "8px 30px", borderRadius: 99, opacity: ease(f, 78, 14), transform: `translateY(${(1 - ease(f, 78, 14)) * 14}px)`,
        }}>IT SKILLS</div>
        <FloatingCard x={1500} y={560} w={270} h={90} start={118} from="scale" radius={45} bobAmp={4}>
          <div style={{height: "100%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 40, fontWeight: 700, color: C.orange}}>এগিয়ে যান</div>
        </FloatingCard>
      </CameraRig>
    </SceneTransition>
  );
};
