import React from "react";
import {C} from "../styles/theme";
import {AnimatedText, WordSpec} from "../components/AnimatedText";
import {CameraRig} from "../components/CameraRig";
import {CertificateCard} from "../components/CertificateCard";
import {SceneTransition} from "../components/SceneTransition";
import {StepTag} from "../components/StepTag";
import {useScene} from "../utils/scene";
import {W} from "../utils/timing";

export const Scene06: React.FC = () => {
  const {dur, at} = useScene("s6");
  const head: WordSpec[][] = [[
    {t: "সরকার", at: at(W.GOVT)}, {t: "অনুমোদিত", at: at(W.APPROVED), color: C.orange},
  ]];
  const sub: WordSpec[][] = [
    [{t: "অনলাইন", at: at(W.ONLINE)}, {t: "ভেরিফাইড", at: at(W.VERIFIED)}],
    [{t: "সার্টিফিকেট", at: at(W.CERT), color: C.orange}],
  ];
  return (
    <SceneTransition duration={dur} inFrames={10} outFrames={8} mode="fade">
      <CameraRig from={{scale: 1}} to={{scale: 1.04}} frames={dur}>
        <StepTag n={3} start={0} />
        <div style={{position: "absolute", left: 130, top: 330}}>
          <AnimatedText lines={head} size={96} />
          <AnimatedText lines={sub} size={70} weight={600} color={C.charcoal} style={{marginTop: 26}} />
        </div>
        <CertificateCard x={1000} y={270} width={760} start={0}
          scanStart={at(W.ONLINE)} scanDur={28} checkStart={at(W.CERT)} zoomStart={at(W.CERT) + 8} />
      </CameraRig>
    </SceneTransition>
  );
};
