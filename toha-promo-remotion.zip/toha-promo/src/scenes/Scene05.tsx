import React from "react";
import {C} from "../styles/theme";
import {AnimatedText, WordSpec} from "../components/AnimatedText";
import {BookIllustration, OpenBook} from "../components/BookIllustration";
import {CameraRig} from "../components/CameraRig";
import {SceneTransition} from "../components/SceneTransition";
import {StepTag} from "../components/StepTag";
import {useScene} from "../utils/scene";
import {W} from "../utils/timing";

export const Scene05: React.FC = () => {
  const {dur, at} = useScene("s5");
  const lines: WordSpec[][] = [
    [{t: "প্রয়োজনীয়", at: at(W.PROYOJONIYO)}],
    [{t: "প্রশিক্ষণ", at: at(W.PROSHIKKHON), color: C.orange}, {t: "বই", at: at(W.BOI), color: C.orange}],
  ];
  return (
    <SceneTransition duration={dur} inFrames={10} outFrames={14} mode="slide">
      <CameraRig from={{scale: 1}} to={{scale: 1.02}} frames={dur}>
        <StepTag n={2} start={0} />
        <div style={{position: "absolute", left: 150, top: 380}}>
          <AnimatedText lines={lines} size={112} lineHeight={1.35} />
        </div>
        <OpenBook x={1020} y={150} width={600} start={26} flipStart={44} />
        <BookIllustration x={1050} y={820} width={540} color={C.charcoal} dark="#18181B" start={0} />
        <BookIllustration x={1075} y={724} width={500} color={C.amber} dark="#F59E0B" start={8} />
        <BookIllustration x={1060} y={632} width={520} color={C.orange} dark={C.orangeDark} start={16} />
      </CameraRig>
    </SceneTransition>
  );
};
