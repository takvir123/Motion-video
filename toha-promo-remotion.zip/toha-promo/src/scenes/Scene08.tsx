import React from "react";
import {Easing, useCurrentFrame} from "remotion";
import {C} from "../styles/theme";
import {AnimatedText, WordSpec} from "../components/AnimatedText";
import {CameraRig} from "../components/CameraRig";
import {DiscountBadge} from "../components/DiscountBadge";
import {SceneTransition} from "../components/SceneTransition";
import {ease, pop} from "../utils/motion";
import {useScene} from "../utils/scene";
import {W} from "../utils/timing";

const Wallet: React.FC<{start: number}> = ({start}) => {
  const f = useCurrentFrame();
  const o = ease(f, start, 14);
  const drop = ease(f, start + 6, 26, Easing.in(Easing.cubic));
  const coinY = -150 + 150 * drop - 30 * pop(f, start + 32);
  const check = ease(f, start + 36, 14);
  return (
    <svg width="360" height="300" viewBox="0 0 360 300" style={{opacity: o, overflow: "visible"}}>
      <ellipse cx="180" cy="284" rx="150" ry="10" fill="#18181B" opacity="0.07" />
      <rect x="30" y="80" width="300" height="190" rx="34" fill={C.white} stroke={C.orange} strokeWidth="8" />
      <path d="M30 130h300" stroke={C.orange} strokeWidth="8" />
      <rect x="230" y="170" width="100" height="56" rx="28" fill={C.orange} />
      <circle cx="262" cy="198" r="9" fill="#fff" />
      <g transform={`translate(180 ${110 + coinY})`} opacity={1 - ease(f, start + 30, 6)}>
        <circle r="44" fill={C.amber} stroke={C.orange} strokeWidth="6" />
        <text textAnchor="middle" y="16" fontSize="48" fontWeight="700" fill={C.orangeDark}>৳</text>
      </g>
      <circle cx="70" cy="215" r={26 * check} fill={C.orange} />
      <path d="M58 215l9 9 17-19" pathLength={1} fill="none" stroke="#fff" strokeWidth="7" strokeLinecap="round"
        strokeLinejoin="round" strokeDasharray="1" strokeDashoffset={1 - check} />
    </svg>
  );
};

export const Scene08: React.FC = () => {
  const {f, dur, at} = useScene("s8");
  const hAt = at(W.SPECIAL_OPP);
  const sAt = at(W.ADM2);
  const head: WordSpec[][] = [[{t: "বিশেষ", at: hAt, color: C.orange}, {t: "সুযোগ", at: hAt + 8, color: C.orange}]];
  const sub: WordSpec[][] = [[{t: "একসাথে", at: sAt}, {t: "ফি", at: sAt + 8}, {t: "পরিশোধে", at: sAt + 16}]];
  return (
    <SceneTransition duration={dur} inFrames={12} outFrames={10} mode="zoom">
      <CameraRig from={{scale: 1}} to={{scale: 1.08}} frames={dur}>
        <div style={{position: "absolute", left: 140, top: 190}}>
          <AnimatedText lines={head} size={124} />
        </div>
        <div style={{position: "absolute", left: 140, top: 400, opacity: ease(f, sAt, 10)}}>
          <AnimatedText lines={sub} size={64} weight={600} color={C.charcoal} />
        </div>
        <div style={{position: "absolute", left: 200, top: 560}}>
          <Wallet start={sAt + 4} />
        </div>
        <DiscountBadge x={1010} y={190} start={0} amountAt={at(W.FIVE00)} labelAt={at(W.SPECIAL)} />
      </CameraRig>
    </SceneTransition>
  );
};
