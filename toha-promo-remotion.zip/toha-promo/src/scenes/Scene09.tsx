import React from "react";
import {Easing, interpolateColors} from "remotion";
import {C} from "../styles/theme";
import {CameraRig} from "../components/CameraRig";
import {PriceText} from "../components/PriceCard";
import {SceneTransition} from "../components/SceneTransition";
import {ease, easeIO, pop} from "../utils/motion";
import {useScene} from "../utils/scene";
import {W} from "../utils/timing";

export const Scene09: React.FC = () => {
  const {f, dur, at} = useScene("s9");
  const oldAt = at(W.OLDPRICE);
  const trAt = at(W.TRANSFORM);
  const newAt = at(W.NEWPRICE);
  const oldIn = pop(f, oldAt, {damping: 18});
  const tr = easeIO(f, trAt, 26);
  const strike = ease(f, trAt, 18, Easing.inOut(Easing.cubic));
  const np = pop(f, newAt, {damping: 13, stiffness: 90});
  const oldColor = interpolateColors(tr, [0, 1], [C.black, C.gray]);
  return (
    <SceneTransition duration={dur} inFrames={10} outFrames={8} mode="fade">
      <CameraRig from={{scale: 1}} to={{scale: 1.08}} frames={dur}>
        <div style={{
          position: "absolute", left: 0, top: 360, width: 1920, textAlign: "center",
          opacity: Math.min(1, oldIn * 1.5) * (1 - 0.3 * tr),
          transform: `translateY(${-tr * 190}px) scale(${(0.9 + 0.1 * oldIn) * (1 - 0.42 * tr)})`,
        }}>
          <div style={{fontSize: 44, fontWeight: 600, color: C.gray}}>নিয়মিত ফি</div>
          <PriceText amount="৳৫,৫০০" size={220} color={oldColor} strike={strike} />
        </div>
        <div style={{
          position: "absolute", left: 460, top: 440, width: 1000, height: 560, borderRadius: "50%", opacity: np * 0.9,
          background: `radial-gradient(circle, ${C.orange}26 0%, transparent 65%)`,
        }} />
        <div style={{
          position: "absolute", left: 0, top: 468, width: 1920, textAlign: "center", fontSize: 60, fontWeight: 600,
          color: C.orange, opacity: ease(f, at(W.MATRO2), 12),
        }}>মাত্র</div>
        <div style={{
          position: "absolute", left: 0, top: 530, width: 1920, textAlign: "center",
          opacity: Math.min(1, np * 1.5), transform: `scale(${0.72 + 0.28 * np})`,
        }}>
          <PriceText amount="৳৫,০০০" size={320} color={C.orange} underline={easeIO(f, newAt + 14, 22)} />
        </div>
      </CameraRig>
    </SceneTransition>
  );
};
