import React from "react";
import {C} from "../styles/theme";
import {CameraRig} from "../components/CameraRig";
import {FloatingCard} from "../components/FloatingCard";
import {Icon, IconName} from "../components/Icons";
import {PriceCard} from "../components/PriceCard";
import {SceneTransition} from "../components/SceneTransition";
import {bn, ease, easeIO, pop} from "../utils/motion";
import {useScene} from "../utils/scene";
import {W} from "../utils/timing";

const CHIPS: {icon: IconName; n: number; x: number}[] = [
  {icon: "calendar", n: 1, x: 680}, {icon: "book", n: 2, x: 900}, {icon: "cert", n: 3, x: 1120},
];

export const Scene03: React.FC = () => {
  const {f, dur, at} = useScene("s3");
  const priceAt = at(W.PRICE1);
  const sc = 0.88 + 0.12 * pop(f, priceAt, {damping: 14, stiffness: 100});
  const under = easeIO(f, at(W.PRICE1) + 14, 22);
  const tr = easeIO(f, 66, 22);
  return (
    <SceneTransition duration={dur} inFrames={10} outFrames={8} mode="fade">
      <CameraRig from={{scale: 1}} to={{scale: 1.03}} frames={dur}>
        <div style={{position: "absolute", inset: 0, transform: `translateY(${-tr * 190}px) scale(${1 - 0.42 * tr})`, transformOrigin: "50% 40%"}}>
          <PriceCard x={510} y={230} w={900} h={520} start={0} eyebrow="মাত্র" amount="৳৫,৫০০" size={230}
            caption="সম্পূর্ণ কোর্স প্যাকেজ" priceScale={sc} underline={under} captionOpacity={ease(f, 38, 14)} />
        </div>
        {CHIPS.map((c, i) => (
          <FloatingCard key={c.n} x={c.x} y={720} w={160} h={190} start={70 + i * 5} from="bottom" radius={34} bobAmp={5} bobPhase={i}>
            <div style={{display: "flex", flexDirection: "column", alignItems: "center", gap: 14, paddingTop: 30}}>
              <Icon name={c.icon} size={70} />
              <div style={{fontSize: 48, fontWeight: 700, color: C.orange}}>{bn(c.n)}</div>
            </div>
          </FloatingCard>
        ))}
      </CameraRig>
    </SceneTransition>
  );
};
