import React from "react";
import {Easing} from "remotion";
import {BrandEndCard} from "../components/BrandEndCard";
import {CameraRig} from "../components/CameraRig";
import {SceneTransition} from "../components/SceneTransition";
import {useScene} from "../utils/scene";
import {W} from "../utils/timing";

export const Scene10: React.FC = () => {
  const {dur, at} = useScene("s10");
  return (
    <SceneTransition duration={dur} inFrames={10} outFrames={0} mode="fade">
      <CameraRig from={{scale: 1.08}} to={{scale: 1}} frames={dur} easing={Easing.out(Easing.quad)}>
        <BrandEndCard
          preCues={[at(W.AR), at(W.DERI), at(W.KENO)]}
          ctaCues={[at(W.AJI), at(W.APNAR2), at(W.ASON), at(W.NISCHITO), at(W.NISCHITO) + 10]}
          supportAt={80}
          badgeAt={at(W.CONTACT)}
          brandCues={[at(W.BRAND1), at(W.BRAND2), at(W.BRAND3), at(W.BRAND4), at(W.BRAND5)]}
        />
      </CameraRig>
    </SceneTransition>
  );
};
