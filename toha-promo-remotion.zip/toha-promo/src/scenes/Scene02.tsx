import React from "react";
import {Easing} from "remotion";
import {C} from "../styles/theme";
import {AnimatedText, WordSpec} from "../components/AnimatedText";
import {CameraRig, Parallax} from "../components/CameraRig";
import {Icon} from "../components/Icons";
import {LaptopIllustration} from "../components/LaptopIllustration";
import {OfficeAppIcons} from "../components/OfficeAppIcons";
import {SceneTransition} from "../components/SceneTransition";
import {ease, pop} from "../utils/motion";
import {useScene} from "../utils/scene";
import {W} from "../utils/timing";

export const Scene02: React.FC = () => {
  const {f, dur, at} = useScene("s2");
  const badgeAt = at(W.THREE);
  const titleAt = at(W.MICROSOFT);
  const name: WordSpec[][] = [
    [{t: "তোহা", at: at(W.TOHA), color: C.orange}, {t: "কম্পিউটার", at: at(W.COMPUTER)}],
    [{t: "এন্ড", at: at(W.AND)}, {t: "ট্রেনিং", at: at(W.TRAINING)}, {t: "সেন্টার", at: at(W.CENTER)}],
  ];
  const tp = ease(f, titleAt, 18);
  const emph = 1 + 0.05 * Math.sin(Math.PI * ease(f, titleAt + 8, 18, Easing.linear));
  const bp = pop(f, badgeAt, {damping: 14, stiffness: 120});
  const lapIn = ease(f, 0, 20);
  return (
    <SceneTransition duration={dur} inFrames={12} outFrames={10} mode="slide">
      <CameraRig from={{x: 60}} to={{x: -40}} frames={dur}>
        <div style={{position: "absolute", left: 150, top: 200}}>
          <AnimatedText lines={name} size={92} />
        </div>
        <div style={{
          position: "absolute", left: 150, top: 480, opacity: tp,
          transform: `translateY(${(1 - tp) * 24}px) scale(${emph})`, transformOrigin: "left center",
        }}>
          <div style={{fontSize: 66, fontWeight: 700, color: C.black, whiteSpace: "nowrap"}}>
            Microsoft <span style={{color: C.orange}}>Office</span> Application
          </div>
          <div style={{marginTop: 6, height: 8, width: 760 * ease(f, titleAt + 6, 24), borderRadius: 4, background: C.orange}} />
        </div>
        <div style={{
          position: "absolute", left: 150, top: 650, display: "flex", alignItems: "center", gap: 18, background: C.orange,
          color: "#fff", fontSize: 46, fontWeight: 700, padding: "16px 40px", borderRadius: 99,
          opacity: Math.min(1, bp * 1.5), transform: `scale(${bp})`, transformOrigin: "left center",
        }}>
          <Icon name="calendar" size={48} color="#fff" />৩ মাস মেয়াদী কোর্স
        </div>
        <Parallax depth={0.5}>
          <div style={{position: "absolute", left: 1010, top: 400 + (1 - lapIn) * 40, opacity: lapIn}}>
            <LaptopIllustration width={690} start={4} />
          </div>
        </Parallax>
        <Parallax depth={1.2}>
          <OfficeAppIcons layout={[{x: 960, y: 130}, {x: 1260, y: 80}, {x: 1560, y: 170}]} start={20} />
        </Parallax>
      </CameraRig>
    </SceneTransition>
  );
};
