import React from "react";
import {C} from "../styles/theme";

export type IconName =
  | "doc" | "grid" | "chart" | "cap" | "book" | "calendar"
  | "check" | "wallet" | "star" | "laptop" | "cert";

export const Icon: React.FC<{name: IconName; size?: number; color?: string; stroke?: number}> = ({
  name, size = 48, color = C.orange, stroke = 3,
}) => {
  const p = {
    fill: "none", stroke: color, strokeWidth: stroke,
    strokeLinecap: "round" as const, strokeLinejoin: "round" as const,
  };
  let body: React.ReactNode = null;
  switch (name) {
    case "doc": body = <><path {...p} d="M12 5h16l9 9v29H12z" /><path {...p} d="M28 5v9h9M18 24h13M18 31h13" /></>; break;
    case "grid": body = <><rect {...p} x="7" y="9" width="34" height="30" rx="4" /><path {...p} d="M7 19h34M7 29h34M20 9v30" /></>; break;
    case "chart": body = <path {...p} d="M8 40h32M14 40V26M24 40V15M34 40V22" />; break;
    case "cap": body = <><path {...p} d="M24 10 4 20l20 10 20-10z" /><path {...p} d="M12 25v8c0 3 6 6 12 6s12-3 12-6v-8M44 20v12" /></>; break;
    case "book": body = <><path {...p} d="M6 10c6-2 12-2 18 2 6-4 12-4 18-2v28c-6-2-12-2-18 2-6-4-12-4-18-2z" /><path {...p} d="M24 12v28" /></>; break;
    case "calendar": body = <><rect {...p} x="6" y="10" width="36" height="32" rx="5" /><path {...p} d="M6 20h36M16 6v8M32 6v8" /></>; break;
    case "check": body = <path {...p} d="M10 25l9 9 19-20" />; break;
    case "wallet": body = <><rect {...p} x="6" y="12" width="36" height="26" rx="6" /><path {...p} d="M6 20h36" /><circle cx="34" cy="29" r="2.4" fill={color} /></>; break;
    case "star": body = <path {...p} d="M24 6l5.4 11 12.1 1.7-8.8 8.5 2.1 12L24 33.5 13.2 39.2l2.1-12-8.8-8.5L18.6 17z" />; break;
    case "laptop": body = <><rect {...p} x="9" y="10" width="30" height="20" rx="3" /><path {...p} d="M4 36h40" /></>; break;
    case "cert": body = <><rect {...p} x="6" y="9" width="36" height="26" rx="3" /><path {...p} d="M14 18h20M14 25h12" /><circle {...p} cx="34" cy="37" r="5" /></>; break;
  }
  return <svg width={size} height={size} viewBox="0 0 48 48">{body}</svg>;
};
