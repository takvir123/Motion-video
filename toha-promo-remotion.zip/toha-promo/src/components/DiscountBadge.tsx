import React from "react";
import {useCurrentFrame} from "remotion";
import {C} from "../styles/theme";
import {bn, ease, easeIO, lerp, pop} from "../utils/motion";
import {FloatingCard} from "./FloatingCard";
import {Icon} from "./Icons";

export const DiscountBadge: React.FC<{
  x: number; y: number; w?: number; h?: number; start?: number; amountAt: number; labelAt: number;
}> = ({x, y, w = 760, h = 700, start = 0, amountAt, labelAt}) => {
  const f = useCurrentFrame();
  const rot = lerp(-6, -2.5, easeIO(f, 0, 90));
  const amt = Math.round(500 * ease(f, amountAt, 22));
  const amtP = pop(f, amountAt, {damping: 14, stiffness: 100});
  const ribbon = easeIO(f, start + 8, 36);
  const labelP = ease(f, labelAt, 16);
  const starOut = 1 - ease(f, amountAt - 4, 10);
  return (
    <FloatingCard x={x} y={y} w={w} h={h} start={start} from="right" rotate={rot} radius={52} border="transparent"
      bg="linear-gradient(145deg,#FB923C,#F97316 55%,#EA580C)" bobAmp={4} style={{overflow: "hidden"}}>
      <div style={{position: "absolute", right: -120, top: -120, width: 340, height: 340, borderRadius: "50%", background: "#fff", opacity: 0.12}} />
      <div style={{position: "absolute", left: -90, bottom: 160, width: 240, height: 240, borderRadius: "50%", background: "#fff", opacity: 0.08}} />
      <div style={{position: "absolute", left: 0, top: 210, width: "100%", display: "flex", justifyContent: "center", opacity: starOut, transform: `scale(${0.6 + 0.4 * starOut})`}}>
        <Icon name="star" size={170} color="#fff" stroke={2.4} />
      </div>
      <div style={{
        position: "absolute", left: 0, top: 110, width: "100%", textAlign: "center", color: "#fff",
        opacity: ease(f, amountAt, 8), transform: `scale(${0.8 + 0.2 * amtP})`,
      }}>
        <div style={{fontSize: 230, fontWeight: 700, lineHeight: 1.1}}>৳{bn(amt)}</div>
        <div style={{fontSize: 84, fontWeight: 600, opacity: 0.95}}>ছাড়</div>
      </div>
      <div style={{
        position: "absolute", left: -60, bottom: 76, width: w + 120, height: 112, background: C.orangeDark,
        transform: `rotate(-4deg) translateX(${(1 - ribbon) * -(w + 200)}px)`, display: "flex", alignItems: "center",
        justifyContent: "center", color: "#fff", fontSize: 54, fontWeight: 700, boxShadow: "0 12px 30px -12px rgba(0,0,0,0.35)",
      }}>
        <span style={{opacity: labelP, transform: `translateY(${(1 - labelP) * 14}px)`}}>স্পেশাল ডিসকাউন্ট</span>
      </div>
    </FloatingCard>
  );
};
