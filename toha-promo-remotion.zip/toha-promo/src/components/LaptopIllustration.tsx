import React from "react";
import {Easing, useCurrentFrame} from "remotion";
import {C, FONT} from "../styles/theme";
import {ease} from "../utils/motion";

export const LaptopIllustration: React.FC<{width?: number; start?: number}> = ({width = 760, start = 0}) => {
  const f = useCurrentFrame();
  const bars = [70, 115, 95, 160, 215];
  const trend = ease(f, start + 30, 40, Easing.inOut(Easing.cubic));
  return (
    <svg width={width} height={width * 0.65} viewBox="0 0 800 520" style={{overflow: "visible", fontFamily: FONT}}>
      <ellipse cx="400" cy="486" rx="360" ry="16" fill="#18181B" opacity="0.07" />
      <rect x="110" y="20" width="580" height="370" rx="24" fill={C.charcoal} />
      <rect x="124" y="34" width="552" height="342" rx="14" fill="#FFFFFF" />
      <path d="M124 48a14 14 0 0 1 14-14h524a14 14 0 0 1 14 14v26H124z" fill="#FFF7ED" />
      <circle cx="148" cy="54" r="6" fill={C.orange} />
      <circle cx="168" cy="54" r="6" fill={C.amber} />
      <circle cx="188" cy="54" r="6" fill={C.border} />
      <rect x="148" y="104" width="120" height="16" rx="8" fill={C.orange} opacity={ease(f, start + 8, 14)} />
      <rect x="148" y="136" width="150" height="12" rx="6" fill={C.border} opacity={ease(f, start + 12, 14)} />
      <rect x="148" y="160" width="110" height="12" rx="6" fill={C.border} opacity={ease(f, start + 16, 14)} />
      <rect x="148" y="184" width="130" height="12" rx="6" fill={C.border} opacity={ease(f, start + 20, 14)} />
      {bars.map((h, i) => (
        <rect key={i} x={340 + i * 62} y={340 - h * ease(f, start + 10 + i * 6, 22)} width="42"
          height={h * ease(f, start + 10 + i * 6, 22)} rx="8" fill={i === 4 ? C.orange : C.amber} />
      ))}
      <path d="M355 290 L417 255 L479 270 L541 200 L603 150" pathLength={1} fill="none" stroke={C.black}
        strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" strokeDasharray="1" strokeDashoffset={1 - trend} />
      <path d="M40 396H760L736 432Q733 440 722 440H78Q67 440 64 432Z" fill={C.border} stroke="#D6D3D1" />
      <rect x="340" y="396" width="120" height="10" rx="5" fill="#D6D3D1" />
    </svg>
  );
};
