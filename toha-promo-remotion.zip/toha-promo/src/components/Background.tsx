import React from "react";
import {AbsoluteFill, useCurrentFrame} from "remotion";
import {C} from "../styles/theme";

export const Background: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{background: C.bg}}>
      <div style={{
        position: "absolute", left: -320 + Math.sin(f / 260) * 60, top: -380 + Math.sin(f / 310) * 40,
        width: 1100, height: 1100, borderRadius: "50%",
        background: `radial-gradient(circle, ${C.amber}40 0%, transparent 65%)`,
      }} />
      <div style={{
        position: "absolute", right: -380 + Math.cos(f / 290) * 50, bottom: -420 + Math.cos(f / 340) * 40,
        width: 1200, height: 1200, borderRadius: "50%",
        background: `radial-gradient(circle, ${C.orange}1F 0%, transparent 65%)`,
      }} />
      <svg width="1920" height="1080" style={{position: "absolute", left: 0, top: 0}}>
        <defs>
          <pattern id="dots" width="48" height="48" patternUnits="userSpaceOnUse">
            <circle cx="2" cy="2" r="1.6" fill={C.border} />
          </pattern>
        </defs>
        <rect width="1920" height="1080" fill="url(#dots)" opacity="0.55" />
      </svg>
    </AbsoluteFill>
  );
};
