import React, {createContext, useContext} from "react";
import {AbsoluteFill, Easing, interpolate, useCurrentFrame} from "remotion";

export type Cam = {x?: number; y?: number; scale?: number; rotate?: number};
type Ctx = {x: number; y: number; scale: number};
const CameraContext = createContext<Ctx>({x: 0, y: 0, scale: 1});

/** Deterministic camera: interpolates from -> to over `frames` (scene-local). */
export const CameraRig: React.FC<{
  from?: Cam; to?: Cam; startFrame?: number; frames: number;
  easing?: (t: number) => number; children: React.ReactNode;
}> = ({from = {}, to = {}, startFrame = 0, frames, easing = Easing.inOut(Easing.cubic), children}) => {
  const f = useCurrentFrame();
  const p = interpolate(f, [startFrame, startFrame + frames], [0, 1], {
    extrapolateLeft: "clamp", extrapolateRight: "clamp", easing,
  });
  const g = (k: keyof Cam, d: number) => {
    const a = from[k] ?? d;
    const b = to[k] ?? a;
    return a + (b - a) * p;
  };
  const x = g("x", 0), y = g("y", 0), s = g("scale", 1), r = g("rotate", 0);
  return (
    <AbsoluteFill style={{
      transform: `translate(${x}px, ${y}px) scale(${s}) rotate(${r}deg)`,
      transformOrigin: "50% 50%",
    }}>
      <CameraContext.Provider value={{x, y, scale: s}}>{children}</CameraContext.Provider>
    </AbsoluteFill>
  );
};

/** depth > 0 moves with extra speed vs camera; depth = -1 cancels camera translation. */
export const Parallax: React.FC<{depth: number; children: React.ReactNode}> = ({depth, children}) => {
  const cam = useContext(CameraContext);
  return (
    <AbsoluteFill style={{transform: `translate(${cam.x * depth}px, ${cam.y * depth}px)`}}>
      {children}
    </AbsoluteFill>
  );
};
