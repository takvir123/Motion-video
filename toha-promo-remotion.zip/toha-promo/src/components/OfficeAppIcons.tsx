import React from "react";
import {C} from "../styles/theme";
import {FloatingCard} from "./FloatingCard";

// Generic letter tiles inspired by office apps. No proprietary logos are used.
const APPS = [
  {letter: "W", name: "Word", color: "#3B6FB6"},
  {letter: "X", name: "Excel", color: "#2E8B57"},
  {letter: "P", name: "PowerPoint", color: "#E4572E"},
];

export const OfficeAppTile: React.FC<{letter: string; color: string; size?: number}> = ({letter, color, size = 120}) => (
  <div style={{
    width: size, height: size, borderRadius: size * 0.24, background: color, position: "relative",
    color: "#fff", fontWeight: 700, fontSize: size * 0.56, display: "flex", alignItems: "center", justifyContent: "center",
  }}>
    {letter}
    <div style={{position: "absolute", right: size * 0.12, bottom: size * 0.14, width: size * 0.26, height: 5, borderRadius: 3, background: "#fff", opacity: 0.8}} />
    <div style={{position: "absolute", right: size * 0.12, bottom: size * 0.07, width: size * 0.16, height: 5, borderRadius: 3, background: "#fff", opacity: 0.55}} />
  </div>
);

export const OfficeAppIcons: React.FC<{
  layout: {x: number; y: number}[]; start?: number; stagger?: number;
}> = ({layout, start = 0, stagger = 14}) => (
  <>
    {APPS.map((a, i) => (
      <FloatingCard key={a.name} x={layout[i].x} y={layout[i].y} w={210} h={240} start={start + i * stagger}
        from="bottom" bobAmp={8} bobPhase={i * 1.7} radius={34}>
        <div style={{display: "flex", flexDirection: "column", alignItems: "center", paddingTop: 36, gap: 22}}>
          <OfficeAppTile letter={a.letter} color={a.color} size={120} />
          <div style={{fontSize: 32, fontWeight: 600, color: C.charcoal}}>{a.name}</div>
        </div>
      </FloatingCard>
    ))}
  </>
);
