import React from "react";
import {Easing, useCurrentFrame} from "remotion";
import {C} from "../styles/theme";
import {ease, easeIO, pop} from "../utils/motion";
import {FloatingCard} from "./FloatingCard";

const LINE_Y = 640;
const N1 = 520;
const N2 = 1400;

export const PaymentTimeline: React.FC<{
  card1: number; hi1: number; node2: number; card2: number; hi2: number; total: number;
}> = ({card1, hi1, node2, card2, hi2, total}) => {
  const f = useCurrentFrame();
  const stub = ease(f, card1 - 10, 25);
  const main = ease(f, node2 - 40, 40, Easing.inOut(Easing.cubic));
  const h1 = ease(f, hi1, 16), h2 = ease(f, hi2, 16);
  const pulse = (s: number) => 1 + 0.1 * Math.sin(Math.PI * ease(f, s, 18, Easing.linear));
  const node = (cx: number, on: number, s: number) => (
    <div style={{
      position: "absolute", left: cx - 24, top: LINE_Y - 20, width: 48, height: 48, borderRadius: "50%",
      background: on > 0.5 ? C.orange : C.white, border: `6px solid ${on > 0.5 ? C.orangeDark : C.border}`,
      transform: `scale(${(0.8 + 0.2 * pop(f, s)) * pulse(s)})`, boxShadow: "0 8px 20px -8px rgba(249,115,22,0.5)",
    }} />
  );
  const amountCard = (x: number, start: number, label: string, amount: string, hi: number, hiAt: number) => (
    <FloatingCard x={x} y={290} w={480} h={260} start={start} from="bottom" radius={40}
      border={hi > 0.3 ? C.orange : C.border}>
      <div style={{height: "100%", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 6}}>
        <div style={{fontSize: 46, fontWeight: 600, color: C.gray}}>{label}</div>
        <div style={{fontSize: 112, fontWeight: 700, color: hi > 0.3 ? C.orange : C.charcoal, transform: `scale(${pulse(hiAt)})`}}>{amount}</div>
      </div>
    </FloatingCard>
  );
  return (
    <>
      <div style={{position: "absolute", left: 300, top: LINE_Y, width: 1320, height: 8, borderRadius: 4, background: C.border}} />
      <div style={{position: "absolute", left: 300, top: LINE_Y, width: 220 * stub, height: 8, borderRadius: 4, background: C.orange}} />
      <div style={{position: "absolute", left: N1, top: LINE_Y, width: (N2 - N1) * main, height: 8, borderRadius: 4, background: C.orange}} />
      {node(N1, stub, card1)}
      {node(N2, main, node2)}
      <div style={{position: "absolute", left: N1 - 2, top: 556, width: 4, height: 64, background: C.orange, opacity: ease(f, card1 + 6, 10)}} />
      <div style={{position: "absolute", left: N2 - 2, top: 556, width: 4, height: 64, background: C.orange, opacity: ease(f, card2 + 6, 10)}} />
      {amountCard(N1 - 240, card1, "ভর্তির সময়", "৳৩,০০০", h1, hi1)}
      {amountCard(N2 - 240, card2, "২ মাস পর", "৳২,৫০০", h2, hi2)}
      {/* Proportional bar: 3,000 + 2,500 = 5,500 */}
      <div style={{position: "absolute", left: 460, top: 800, width: 1000, height: 40, borderRadius: 20, background: "#F3F0EB", overflow: "hidden", opacity: ease(f, hi1 - 4, 10)}}>
        <div style={{position: "absolute", left: 0, top: 0, height: "100%", width: 545 * easeIO(f, hi1, 25), background: C.orange}} />
        <div style={{position: "absolute", left: 545, top: 0, height: "100%", width: 455 * easeIO(f, hi2, 25), background: C.amber}} />
      </div>
      <div style={{
        position: "absolute", left: 460, top: 866, width: 1000, textAlign: "center", fontSize: 58, fontWeight: 700,
        color: C.black, opacity: ease(f, total, 14), transform: `translateY(${(1 - ease(f, total, 14)) * 16}px)`,
      }}>
        ৳৩,০০০ + ৳২,৫০০ = <span style={{color: C.orange}}>৳৫,৫০০</span>
      </div>
    </>
  );
};
