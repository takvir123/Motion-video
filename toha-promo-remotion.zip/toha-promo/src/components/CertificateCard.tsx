import React from "react";
import {Easing, useCurrentFrame} from "remotion";
import {C, FONT, SHADOW} from "../styles/theme";
import {ease, easeIO, pop} from "../utils/motion";

// Deterministic decorative pattern. NOT a QR code: no finder squares, nothing scannable.
const PATTERN = Array.from({length: 49}, (_, i) => ((i * 2654435761) >>> 0) % 100 < 52);

/** Purely illustrative certificate. Contains no seal, number, URL or code that implies real verification. */
export const CertificateCard: React.FC<{
  x: number; y: number; width?: number; start?: number;
  scanStart: number; scanDur?: number; checkStart: number; zoomStart?: number;
}> = ({x, y, width = 760, start = 0, scanStart, scanDur = 28, checkStart, zoomStart}) => {
  const f = useCurrentFrame();
  const h = (width * 540) / 760;
  const slide = pop(f, start, {damping: 20, stiffness: 90});
  const zoom = zoomStart !== undefined ? 1 + 0.045 * easeIO(f, zoomStart, 15) : 1;
  const scanP = ease(f, scanStart, scanDur, Easing.inOut(Easing.cubic));
  const scanOn = f >= scanStart && f <= scanStart + scanDur + 4;
  const checkP = ease(f, checkStart, 18);
  const sy = scanP * 540;
  return (
    <div style={{
      position: "absolute", left: x, top: y, width, height: h, borderRadius: 28, background: "#fff",
      boxShadow: SHADOW, overflow: "hidden", opacity: ease(f, start, 12),
      transform: `translateX(${(1 - slide) * 420}px) scale(${zoom})`,
    }}>
      <svg width={width} height={h} viewBox="0 0 760 540" style={{fontFamily: FONT}}>
        <defs>
          <linearGradient id="scanGlow" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor={C.orange} stopOpacity="0" />
            <stop offset="1" stopColor={C.orange} stopOpacity="0.28" />
          </linearGradient>
        </defs>
        <rect x="18" y="18" width="724" height="504" rx="18" fill="none" stroke={C.orange} strokeWidth="4" />
        <rect x="32" y="32" width="696" height="476" rx="12" fill="none" stroke={C.amber} strokeWidth="2" />
        <text x="380" y="132" textAnchor="middle" fontSize="58" fontWeight="700" fill={C.black}>সার্টিফিকেট</text>
        <rect x="290" y="156" width="180" height="6" rx="3" fill={C.orange} />
        <rect x="190" y="212" width="380" height="14" rx="7" fill={C.border} />
        <rect x="140" y="248" width="480" height="12" rx="6" fill="#F3F0EB" />
        <rect x="170" y="276" width="420" height="12" rx="6" fill="#F3F0EB" />
        <g transform="translate(70 340)">
          {PATTERN.map((on, i) => on && (
            <rect key={i} x={(i % 7) * 18} y={Math.floor(i / 7) * 18} width="14" height="14" rx="3" fill={C.charcoal} opacity="0.85" />
          ))}
        </g>
        <polygon points="590,455 568,522 600,506 622,526 628,458" fill={C.amber} />
        <circle cx="620" cy="410" r="58" fill="#FFF7ED" stroke={C.amber} strokeWidth="8" />
        <circle cx="620" cy="410" r={44 * checkP} fill={C.orange} />
        <path d="M599 412 L614 427 L642 393" pathLength={1} fill="none" stroke="#fff" strokeWidth="10"
          strokeLinecap="round" strokeLinejoin="round" strokeDasharray="1" strokeDashoffset={1 - checkP} />
        {scanOn && (
          <>
            <rect x="0" y={sy - 90} width="760" height="90" fill="url(#scanGlow)" />
            <rect x="0" y={sy - 3} width="760" height="6" fill={C.orange} />
          </>
        )}
      </svg>
    </div>
  );
};
