import React from "react";
import {AbsoluteFill, Easing, interpolate, useCurrentFrame} from "remotion";

export const SceneTransition: React.FC<{
  duration: number; inFrames?: number; outFrames?: number;
  mode?: "fade" | "slide" | "zoom"; children: React.ReactNode;
}> = ({duration, inFrames = 12, outFrames = 10, mode = "fade", children}) => {
  const f = useCurrentFrame();
  const clamp = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;
  const inP = interpolate(f, [0, Math.max(1, inFrames)], [0, 1], {...clamp, easing: Easing.out(Easing.cubic)});
  const outP = outFrames > 0
    ? interpolate(f, [duration - outFrames, duration], [0, 1], {...clamp, easing: Easing.in(Easing.cubic)})
    : 0;
  const opacity = inP * (1 - outP);
  let transform = `translateY(${(1 - inP) * 14}px)`;
  if (mode === "slide") transform = `translateX(${(1 - inP) * 70 - outP * 170}px)`;
  if (mode === "zoom") transform = `scale(${0.985 + 0.015 * inP + 0.035 * outP})`;
  return <AbsoluteFill style={{opacity, transform}}>{children}</AbsoluteFill>;
};
