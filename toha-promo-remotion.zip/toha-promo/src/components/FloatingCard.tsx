import React from "react";
import {useCurrentFrame} from "remotion";
import {C, SHADOW} from "../styles/theme";
import {bob, ease, pop} from "../utils/motion";

export const FloatingCard: React.FC<{
  x: number; y: number; w: number; h: number; start?: number;
  from?: "left" | "right" | "top" | "bottom" | "scale"; rotate?: number;
  bobAmp?: number; bobPhase?: number; radius?: number; bg?: string; border?: string;
  shadow?: boolean; style?: React.CSSProperties; children?: React.ReactNode;
}> = ({
  x, y, w, h, start = 0, from = "bottom", rotate = 0, bobAmp = 6, bobPhase = 0,
  radius = 36, bg = C.white, border = C.border, shadow = true, style, children,
}) => {
  const f = useCurrentFrame();
  const p = pop(f, start, {damping: 18, stiffness: 100});
  const o = ease(f, start, 14);
  const dist = 140;
  const dx = from === "left" ? -dist : from === "right" ? dist : 0;
  const dy = from === "top" ? -dist : from === "bottom" ? dist : 0;
  const b = bob(f, bobAmp, 100, bobPhase) * o;
  const sc = from === "scale" ? 0.8 + 0.2 * p : 0.96 + 0.04 * p;
  return (
    <div style={{
      position: "absolute", left: x, top: y, width: w, height: h, borderRadius: radius,
      background: bg, border: `2px solid ${border}`, boxShadow: shadow ? SHADOW : "none",
      opacity: o, transform: `translate(${dx * (1 - p)}px, ${dy * (1 - p) + b}px) rotate(${rotate}deg) scale(${sc})`,
      ...style,
    }}>{children}</div>
  );
};
