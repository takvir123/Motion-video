import React from "react";
import {C} from "../styles/theme";
import {FloatingCard} from "./FloatingCard";

export const PriceText: React.FC<{
  amount: string; size: number; color?: string; underline?: number; strike?: number;
}> = ({amount, size, color = C.black, underline = 0, strike = 0}) => (
  <div style={{position: "relative", display: "inline-block", fontSize: size, fontWeight: 700, color, lineHeight: 1.15}}>
    {amount}
    {underline > 0 && (
      <div style={{
        position: "absolute", left: 0, bottom: -size * 0.04, height: size * 0.06,
        width: `${underline * 100}%`, background: C.orange, borderRadius: 99,
      }} />
    )}
    {strike > 0 && (
      <svg viewBox="0 0 100 100" preserveAspectRatio="none"
        style={{position: "absolute", left: -size * 0.06, top: 0, width: "112%", height: "100%", overflow: "visible"}}>
        <line x1="0" y1="64" x2={100 * strike} y2={64 - 26 * strike} stroke={C.orange}
          strokeWidth={Math.max(6, size * 0.05)} strokeLinecap="round" vectorEffect="non-scaling-stroke" />
      </svg>
    )}
  </div>
);

export const PriceCard: React.FC<{
  x: number; y: number; w: number; h: number; start?: number;
  amount: string; size: number; caption?: string; eyebrow?: string;
  priceScale?: number; underline?: number; captionOpacity?: number;
}> = ({x, y, w, h, start = 0, amount, size, caption, eyebrow, priceScale = 1, underline = 0, captionOpacity = 1}) => (
  <FloatingCard x={x} y={y} w={w} h={h} start={start} from="bottom" radius={48}>
    <div style={{height: "100%", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 10}}>
      {eyebrow && <div style={{fontSize: 54, fontWeight: 600, color: C.orange}}>{eyebrow}</div>}
      <div style={{transform: `scale(${priceScale})`}}>
        <PriceText amount={amount} size={size} underline={underline} />
      </div>
      {caption && <div style={{fontSize: 48, fontWeight: 600, color: C.gray, opacity: captionOpacity, marginTop: 18}}>{caption}</div>}
    </div>
  </FloatingCard>
);
