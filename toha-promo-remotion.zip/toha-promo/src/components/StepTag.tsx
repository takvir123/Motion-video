import React from "react";
import {useCurrentFrame} from "remotion";
import {C} from "../styles/theme";
import {bn, pop} from "../utils/motion";

export const StepTag: React.FC<{n: number; start?: number; x?: number; y?: number}> = ({
  n, start = 0, x = 150, y = 130,
}) => {
  const f = useCurrentFrame();
  const p = pop(f, start);
  return (
    <div style={{
      position: "absolute", left: x, top: y, display: "flex", alignItems: "center", gap: 18,
      transform: `scale(${p})`, transformOrigin: "left center", opacity: Math.min(1, p * 2),
    }}>
      <div style={{
        width: 88, height: 88, borderRadius: "50%", background: C.orange, color: "#fff",
        fontSize: 52, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center",
      }}>{bn(n)}</div>
      <div style={{fontSize: 36, color: C.gray, fontWeight: 600}}>{bn(n)} / ৩</div>
    </div>
  );
};
