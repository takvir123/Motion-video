import React from "react";
import {Easing, useCurrentFrame} from "remotion";
import {C} from "../styles/theme";
import {ease, pop} from "../utils/motion";

/** Closed book seen from the side (cover, spine, page edge). Rises with a spring. */
export const BookIllustration: React.FC<{
  x: number; y: number; width?: number; color: string; dark: string; start?: number;
}> = ({x, y, width = 480, color, dark, start = 0}) => {
  const f = useCurrentFrame();
  const p = pop(f, start, {damping: 16, stiffness: 90});
  return (
    <div style={{
      position: "absolute", left: x, top: y, opacity: ease(f, start, 10),
      transform: `translateY(${(1 - p) * 260}px)`,
    }}>
      <svg width={width} height={width * 0.21} viewBox="0 0 400 84" style={{overflow: "visible"}}>
        <rect x="0" y="0" width="400" height="84" rx="12" fill={color} />
        <rect x="26" y="10" width="366" height="64" rx="4" fill="#FFFFFF" stroke={C.border} />
        <path d="M40 28H380M40 42H380M40 56H380" stroke={C.border} strokeWidth="2" />
        <rect x="0" y="0" width="30" height="84" rx="12" fill={dark} />
        <rect x="9" y="34" width="14" height="16" rx="3" fill="#fff" opacity="0.85" />
      </svg>
    </div>
  );
};

/** Open book: a page flips, then text lines are revealed. */
export const OpenBook: React.FC<{x: number; y: number; width?: number; start?: number; flipStart: number}> = ({
  x, y, width = 560, start = 0, flipStart,
}) => {
  const f = useCurrentFrame();
  const p = pop(f, start, {damping: 18});
  const flip = ease(f, flipStart, 26, Easing.inOut(Easing.cubic));
  const sx = Math.cos(Math.PI * flip);
  const reveal = ease(f, flipStart + 20, 30);
  const reveal2 = ease(f, flipStart + 8, 30);
  const L = "M280 40 C200 10 110 10 40 40 V300 C110 270 200 270 280 300 Z";
  const R = "M280 40 C360 10 450 10 520 40 V300 C450 270 360 270 280 300 Z";
  const lines = [90, 118, 146, 174, 202, 230];
  return (
    <div style={{
      position: "absolute", left: x, top: y, opacity: ease(f, start, 12),
      transform: `translateY(${(1 - p) * 120}px)`,
    }}>
      <svg width={width} height={width * (340 / 560)} viewBox="0 0 560 340" style={{overflow: "visible"}}>
        <ellipse cx="280" cy="326" rx="250" ry="12" fill="#18181B" opacity="0.07" />
        <path d="M280 56 C200 26 100 26 24 56 V316 C100 286 200 286 280 316 C360 286 460 286 536 316 V56 C460 26 360 26 280 56Z" fill={C.orange} />
        <path d={L} fill="#fff" stroke={C.border} strokeWidth="2" />
        <path d={R} fill="#fff" stroke={C.border} strokeWidth="2" />
        <clipPath id="revealL"><rect x="40" y="0" width={240 * reveal} height="340" /></clipPath>
        <clipPath id="revealR"><rect x="280" y="0" width={240 * reveal2} height="340" /></clipPath>
        <g clipPath="url(#revealL)">
          <rect x="70" y="62" width="90" height="16" rx="8" fill={C.orange} />
          {lines.map((ly) => <path key={ly} d={`M70 ${ly}H250`} stroke={C.border} strokeWidth="8" strokeLinecap="round" />)}
        </g>
        <g clipPath="url(#revealR)">
          <rect x="310" y="62" width="70" height="16" rx="8" fill={C.amber} />
          {lines.map((ly) => <path key={ly} d={`M310 ${ly}H490`} stroke={C.border} strokeWidth="8" strokeLinecap="round" />)}
        </g>
        <path d="M280 40V300" stroke={C.border} strokeWidth="3" />
        {flip > 0 && flip < 1 && (
          <g transform={`translate(280 0) scale(${sx} 1) translate(-280 0)`}>
            <path d={R} fill="#fff" stroke={C.border} strokeWidth="2" />
            {lines.map((ly) => <path key={ly} d={`M310 ${ly}H490`} stroke={C.border} strokeWidth="8" strokeLinecap="round" />)}
          </g>
        )}
      </svg>
    </div>
  );
};
