import React from "react";
import {Easing, useCurrentFrame} from "remotion";
import {C} from "../styles/theme";
import {ease} from "../utils/motion";

export type WordSpec = {t: string; at: number; color?: string; pulse?: boolean};

export const lineOf = (text: string, start: number, stagger = 6, color?: string): WordSpec[] =>
  text.split(" ").map((t, i) => ({t, at: start + i * stagger, color}));

/** Per-word reveal. Each word has its own (scene-local) start frame, usually from the timestamp JSON. */
export const AnimatedText: React.FC<{
  lines: WordSpec[][]; size?: number; weight?: number; color?: string;
  align?: "left" | "center"; lineHeight?: number; style?: React.CSSProperties;
}> = ({lines, size = 64, weight = 700, color = C.black, align = "left", lineHeight = 1.3, style}) => {
  const f = useCurrentFrame();
  return (
    <div style={{fontSize: size, fontWeight: weight, color, lineHeight, ...style}}>
      {lines.map((line, li) => (
        <div key={li} style={{
          display: "flex", whiteSpace: "nowrap",
          justifyContent: align === "center" ? "center" : "flex-start", gap: `0 ${size * 0.26}px`,
        }}>
          {line.map((w, wi) => {
            const p = ease(f, w.at, 18);
            const pulse = w.pulse ? 1 + 0.12 * Math.sin(Math.PI * ease(f, w.at, 22, Easing.linear)) : 1;
            return (
              <span key={wi} style={{
                display: "inline-block", opacity: p, color: w.color ?? color,
                transform: `translateY(${(1 - p) * size * 0.35}px) scale(${pulse})`,
                transformOrigin: "50% 80%",
              }}>{w.t}</span>
            );
          })}
        </div>
      ))}
    </div>
  );
};
