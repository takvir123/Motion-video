import React from "react";
import {Easing, interpolate, useCurrentFrame} from "remotion";
import {C, FONT} from "../styles/theme";
import {bn, ease} from "../utils/motion";
import {FloatingCard} from "./FloatingCard";

const useProg = (fillStart: number, fillEnd: number) => {
  const f = useCurrentFrame();
  return interpolate(f, [fillStart, fillEnd], [0, 1], {
    extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.inOut(Easing.cubic),
  });
};

export const CalendarAnimation: React.FC<{
  x: number; y: number; start?: number; fillStart: number; fillEnd: number;
}> = ({x, y, start = 0, fillStart, fillEnd}) => {
  const f = useCurrentFrame();
  const prog = useProg(fillStart, fillEnd);
  const count = Math.min(90, Math.floor(prog * 90 + 0.0001));
  const flip = ease(f, fillStart - 14, 18, Easing.inOut(Easing.cubic));
  return (
    <FloatingCard x={x} y={y} w={500} h={560} start={start} from="left" radius={36} bobAmp={5}
      style={{perspective: 1200}}>
      <div style={{
        height: 120, background: C.orange, borderRadius: "34px 34px 0 0", color: "#fff", fontSize: 46,
        fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center",
      }}>৩ মাস</div>
      {[110, 340].map((l) => (
        <div key={l} style={{
          position: "absolute", top: -20, left: l, width: 20, height: 56, borderRadius: 10,
          background: C.charcoal, border: `3px solid ${C.white}`,
        }} />
      ))}
      <div style={{
        position: "absolute", left: 44, top: 164, display: "grid",
        gridTemplateColumns: "repeat(10, 30px)", gap: 12,
      }}>
        {Array.from({length: 90}, (_, i) => (
          <div key={i} style={{
            width: 30, height: 30, borderRadius: 9,
            background: i < count ? (i === count - 1 ? C.orangeDark : C.orange) : "#F3F0EB",
          }} />
        ))}
      </div>
      <div style={{
        position: "absolute", left: 0, top: 120, width: "100%", height: 440, background: C.white,
        borderRadius: "0 0 34px 34px", transformOrigin: "top", transform: `rotateX(${-flip * 100}deg)`,
        opacity: 1 - flip, display: "flex", alignItems: "center", justifyContent: "center",
        fontSize: 220, fontWeight: 700, color: C.orange, fontFamily: FONT,
      }}>১</div>
    </FloatingCard>
  );
};

export const ProgressRing: React.FC<{
  x: number; y: number; size?: number; start?: number; fillStart: number; fillEnd: number;
}> = ({x, y, size = 300, start = 0, fillStart, fillEnd}) => {
  const prog = useProg(fillStart, fillEnd);
  const r = size * 0.38;
  const c = 2 * Math.PI * r;
  return (
    <FloatingCard x={x} y={y} w={size} h={size} start={start} from="right" radius={size / 2} bobAmp={7} bobPhase={1.3}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{position: "absolute", left: -2, top: -2}}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#F3F0EB" strokeWidth="20" />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={C.orange} strokeWidth="20" strokeLinecap="round"
          strokeDasharray={c} strokeDashoffset={c * (1 - prog)} transform={`rotate(-90 ${size / 2} ${size / 2})`} />
      </svg>
      <div style={{position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center"}}>
        <div style={{fontSize: 96, fontWeight: 700, color: C.black, lineHeight: 1}}>{bn(Math.round(prog * 90))}</div>
        <div style={{fontSize: 34, fontWeight: 600, color: C.gray}}>দিন</div>
      </div>
    </FloatingCard>
  );
};
