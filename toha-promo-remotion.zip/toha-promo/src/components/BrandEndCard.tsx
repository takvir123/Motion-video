import React from "react";
import {useCurrentFrame} from "remotion";
import {C} from "../styles/theme";
import {ease, bob, pop} from "../utils/motion";
import {AnimatedText, WordSpec} from "./AnimatedText";
import {Icon, IconName} from "./Icons";

const ICONS: {name: IconName; x: number; y: number; at: number}[] = [
  {name: "cap", x: 170, y: 150, at: 40}, {name: "book", x: 140, y: 470, at: 52}, {name: "calendar", x: 190, y: 790, at: 64},
  {name: "cert", x: 1640, y: 150, at: 46}, {name: "laptop", x: 1670, y: 470, at: 58}, {name: "check", x: 1630, y: 790, at: 70},
];

export const BrandEndCard: React.FC<{
  preCues: number[]; ctaCues: number[]; supportAt: number; badgeAt: number; brandCues: number[];
}> = ({preCues, ctaCues, supportAt, badgeAt, brandCues}) => {
  const f = useCurrentFrame();
  const ctaAt = ctaCues[0];
  const preOut = 1 - ease(f, ctaAt - 8, 10);
  const line = ease(f, 0, 40);
  const pre: WordSpec[][] = [[
    {t: "আর", at: preCues[0]}, {t: "দেরি", at: preCues[1]}, {t: "কেন?", at: preCues[2], color: C.orange},
  ]];
  const cta: WordSpec[][] = [[
    {t: "আজই", at: ctaCues[0]}, {t: "আপনার", at: ctaCues[1]},
    {t: "আসন", at: ctaCues[2], color: C.orange}, {t: "নিশ্চিত", at: ctaCues[3]}, {t: "করুন", at: ctaCues[4]},
  ]];
  const brand: WordSpec[][] = [[
    {t: "তোহা", at: brandCues[0], color: C.orange}, {t: "কম্পিউটার", at: brandCues[1]},
    {t: "এন্ড", at: brandCues[2]}, {t: "ট্রেনিং", at: brandCues[3]}, {t: "সেন্টার", at: brandCues[4]},
  ]];
  const sp = ease(f, supportAt, 16);
  const bp = pop(f, badgeAt, {damping: 16, stiffness: 100});
  const mono = pop(f, brandCues[0] - 4);
  return (
    <>
      <div style={{position: "absolute", left: 960 - 550 * line, top: 64, width: 1100 * line, height: 6, borderRadius: 3, background: C.orange}} />
      <div style={{position: "absolute", left: 960 - 550 * line, top: 1010, width: 1100 * line, height: 6, borderRadius: 3, background: C.amber}} />
      {ICONS.map((ic, i) => {
        const p = pop(f, ic.at);
        return (
          <div key={ic.name} style={{
            position: "absolute", left: ic.x, top: ic.y + bob(f, 8, 100, i * 1.1) * p, width: 118, height: 118,
            borderRadius: 34, background: C.white, border: `2px solid ${C.border}`, display: "flex",
            alignItems: "center", justifyContent: "center", opacity: p * 0.95, transform: `scale(${p})`,
            boxShadow: "0 20px 40px -20px rgba(24,24,27,0.2)",
          }}><Icon name={ic.name} size={58} /></div>
        );
      })}
      <div style={{position: "absolute", left: 0, top: 410, width: 1920, opacity: preOut}}>
        <AnimatedText lines={pre} size={170} align="center" />
      </div>
      <div style={{position: "absolute", left: 0, top: 170, width: 1920}}>
        <AnimatedText lines={cta} size={100} align="center" />
      </div>
      <div style={{
        position: "absolute", left: 0, top: 330, width: 1920, textAlign: "center", fontSize: 46, fontWeight: 500,
        color: C.gray, opacity: sp, transform: `translateY(${(1 - sp) * 16}px)`,
      }}>Microsoft Office Application Course</div>
      <div style={{
        position: "absolute", left: 640, top: 430, width: 640, height: 200, borderRadius: 44, color: "#fff",
        background: "linear-gradient(145deg,#FB923C,#F97316 60%,#EA580C)", display: "flex", flexDirection: "column",
        alignItems: "center", justifyContent: "center", opacity: Math.min(1, bp * 1.5), transform: `scale(${0.85 + 0.15 * bp})`,
        boxShadow: "0 30px 60px -28px rgba(234,88,12,0.6)",
      }}>
        <div style={{fontSize: 88, fontWeight: 700, lineHeight: 1.15}}>মাত্র ৳৫,০০০</div>
        <div style={{fontSize: 38, fontWeight: 600, opacity: 0.95}}>একসাথে ফি পরিশোধে</div>
      </div>
      <div style={{position: "absolute", left: 0, top: 730, width: 1920, display: "flex", justifyContent: "center", alignItems: "center", gap: 28}}>
        <div style={{
          width: 112, height: 112, borderRadius: "50%", background: C.orange, color: "#fff", fontSize: 64, fontWeight: 700,
          display: "flex", alignItems: "center", justifyContent: "center", transform: `scale(${mono})`,
        }}>ত</div>
        <AnimatedText lines={brand} size={76} />
      </div>
      <div style={{position: "absolute", left: 660, top: 880, width: 600 * ease(f, brandCues[4], 24), height: 6, borderRadius: 3, background: C.orange}} />
    </>
  );
};
