# Toha Computer & Training Center — Remotion Promo (1920×1080, 30 FPS, 1566 frames)

## Setup
```bash
npm install
```
The first run downloads Hind Siliguri through `@remotion/google-fonts` (internet needed once).
Offline option: put a Bengali TTF in `public/fonts/` and load it with `staticFile()` in `src/styles/theme.ts`.

## Preview
```bash
npm start
```

## Render MP4
```bash
npx remotion render TohaPromo out/toha-promo.mp4
```
Check one frame: `npx remotion still TohaPromo out/frame.png --frame=1300`

## Inputs
- `public/audio/voiceover.ogg` — the original narration you supplied, unmodified.
- `src/data/timestamps.json` — your timestamp JSON, unmodified. All cues come from it via `src/utils/timing.ts`
  (`timestampToFrame`, `getWordTiming`, `W` word-index map, `SCENES`).

## Verification checklist
- [ ] Composition is 1566 frames, 1920×1080, 30 FPS
- [ ] Audio plays from frame 0 and ends with the video (~52.2 s)
- [ ] ৯০ highlights at 00:15.000, ৳৩,০০০ at 00:29.400, second node at 00:31.300, ৳২,৫০০ at 00:32.250
- [ ] Discount ৳৫০০ animates at 00:39.500, label at 00:40.150
- [ ] ৳৫,৫০০ shown at 00:42.000, struck at 00:43.400, ৳৫,০০০ revealed at 00:44.300
- [ ] CTA at 00:47.000, brand name at 00:50.000
- [ ] Bengali glyphs (যুক্তাক্ষর) render correctly in all scenes
- [ ] No invented phone, address, website, logo, seal, QR or accreditation number
